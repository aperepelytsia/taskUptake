package page.uptake;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import page.AbstractPage;


public class IndustriesPage extends AbstractPage {

	By industriesPage = new By.ByXPath(
			".//a[contains(@class, 'menu__item menu__item--active') and text() = 'Industries']");
	By newsroomPageLocator = new By.ByXPath(".//a[contains(@class, 'menu__item') and text() = 'Newsroom']");

	public void verifyPage() {

		LOGGER.info("Verifying the Industries page loaded");
		try {

			wait.until(ExpectedConditions.visibilityOfElementLocated(industriesPage));
		} catch (Exception e) {
			String message = "Failed to load the page";
			LOGGER.error(message, e);
			Assert.fail(message + e.getMessage());
		}
	}

	public NewsroomPage openNewsroomPage() {
		LOGGER.info("Opening Newsroom Page");
		driver.findElement(newsroomPageLocator).click();
		NewsroomPage newsroomPage = new NewsroomPage();
		newsroomPage.verifyPage();
		return newsroomPage;

	}
}
