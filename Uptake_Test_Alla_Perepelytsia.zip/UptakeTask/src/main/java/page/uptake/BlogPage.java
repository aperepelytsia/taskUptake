
package page.uptake;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import page.AbstractPage;


public class BlogPage extends AbstractPage {

	By blogTitle = new By.ByCssSelector("p.blog-title");

	public void verifyPage() {

		LOGGER.info("Verifying the Blog page loaded");
		try {

			wait.until(ExpectedConditions.visibilityOfElementLocated(blogTitle));
		} catch (Exception e) {
			String message = "Failed to load the page";
			LOGGER.error(message, e);
			Assert.fail(message + e.getMessage());
		}
	}

}

