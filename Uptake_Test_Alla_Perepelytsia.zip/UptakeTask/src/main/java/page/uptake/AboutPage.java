package page.uptake;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import page.AbstractPage;

public class AboutPage extends AbstractPage {

	By aboutPage = new By.ByXPath(".//a[contains(@class, 'menu__item menu__item--active') and text() = 'About']");
	By productsPageLocator = new By.ByXPath(".//a[contains(@class, 'menu__item') and text() = 'Products']");

	public void verifyPage() {

		LOGGER.info("Verifying the About page loaded");
		try {

			wait.until(ExpectedConditions.visibilityOfElementLocated(aboutPage));
		} catch (Exception e) {
			String message = "Failed to load the page";
			LOGGER.error(message, e);
			Assert.fail(message + e.getMessage());
		}
	}

	public ProductsPage openProductsPage() {
		LOGGER.info("Opening Prodcuts Page");
		driver.findElement(productsPageLocator).click();
		ProductsPage productsPage = new ProductsPage();
		productsPage.verifyPage();
		return productsPage;

	}
}
