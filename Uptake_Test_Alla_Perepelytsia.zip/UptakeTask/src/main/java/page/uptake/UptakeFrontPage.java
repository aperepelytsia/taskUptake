package page.uptake;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import page.AbstractPage;
import util.UrlProvider;

public class UptakeFrontPage extends AbstractPage {

	By frontTitleLocator = new By.ByXPath(".//p[contains(text(),'Actionable Insights')]");
	By aboutPageLocator = new By.ByXPath(".//a[contains(@class, 'menu__item') and text() = 'About']");

	public UptakeFrontPage() {
		url = UrlProvider.getUrl("uptake");
	}

	public void verifyPage() {
		LOGGER.info("Verifying the front page loaded");

		try {

			wait.until(ExpectedConditions.visibilityOfElementLocated(frontTitleLocator));
		} catch (Exception e) {
			String message = "Failed to load the page";
			LOGGER.error(message, e);
			Assert.fail(message + e.getMessage());
		}
	}

	public void verifyFrontTitle(String expectedFrontTitle) {

		WebElement actualFrontTitle = driver.findElement(frontTitleLocator);
		LOGGER.info("Verifying the front page title contains: " + expectedFrontTitle);
		String message = "The Front page title did not match with the expected one: " + expectedFrontTitle;
		Assert.assertEquals(message, expectedFrontTitle, actualFrontTitle.getText());

	}

	public AboutPage openAboutPage() {
		LOGGER.info("Opening About Page");
		driver.findElement(aboutPageLocator).click();
		AboutPage aboutPage = new AboutPage();
		aboutPage.verifyPage();
		return aboutPage;

	}
}
