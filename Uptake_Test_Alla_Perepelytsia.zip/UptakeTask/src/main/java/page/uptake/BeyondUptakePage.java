package page.uptake;

import java.util.ArrayList;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import page.AbstractPage;

public class BeyondUptakePage extends AbstractPage {

	By beyondUptakePageLogo = new By.ByCssSelector("div.navbar-header.page-scroll");

	public void verifyPage() {

		LOGGER.info("Verifying the Beyond.Uptake page loaded");
		try {

			wait.until(ExpectedConditions.visibilityOfElementLocated(beyondUptakePageLogo));
		} catch (Exception e) {
			String message = "Failed to load the page";
			LOGGER.error(message, e);
			Assert.fail(message + e.getMessage());
		}
	}

	public NewsroomPage returnToNewsroomPage() {
		LOGGER.info("Returning to Newsroom Page");
		ArrayList<String> windowHandles = new ArrayList<String>(driver.getWindowHandles());
		String newsroomTab = windowHandles.get(0);
		driver.switchTo().window(newsroomTab);
		NewsroomPage newsroomPage = new NewsroomPage();
		newsroomPage.verifyPage();
		return newsroomPage;
	}
}