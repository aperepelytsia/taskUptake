package page.uptake;

import java.util.ArrayList;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import page.AbstractPage;

public class NewsroomPage extends AbstractPage {

	By newsroomPage = new By.ByXPath(".//a[contains(@class, 'menu__item menu__item--active') and text() = 'Newsroom']");
	By beyondUptakePageLocator = new By.ByXPath(".//a[contains(@class, 'menu__item') and text() = 'Beyond.Uptake']");
	By blogPageLocator = new By.ByXPath(".//a[contains(@class, 'menu__item') and text() = 'Blog']");

	public void verifyPage() {

		LOGGER.info("Verifying the Newsroom page loaded");
		try {

			wait.until(ExpectedConditions.visibilityOfElementLocated(newsroomPage));
		} catch (Exception e) {
			String message = "Failed to load the page";
			LOGGER.error(message, e);
			Assert.fail(message + e.getMessage());
		}
	}

	public BeyondUptakePage openBeyondUptakePage() {
		LOGGER.info("Opening Beyond.Uptake Page");
		driver.findElement(beyondUptakePageLocator).click();
		ArrayList<String> windowHandles = new ArrayList<String>(driver.getWindowHandles());
		String beyondUptakeTab = windowHandles.get(1);
		driver.switchTo().window(beyondUptakeTab);
		BeyondUptakePage beyondUptakePage = new BeyondUptakePage();
		beyondUptakePage.verifyPage();
		return beyondUptakePage;

	}

	public BlogPage openBlogPage() {
		LOGGER.info("Opening Blog Page");
		driver.findElement(blogPageLocator).click();
		ArrayList<String> windowHandles = new ArrayList<String>(driver.getWindowHandles());
		String blogTab = windowHandles.get(2);
		driver.switchTo().window(blogTab);
		BlogPage blogPage = new BlogPage();
		blogPage.verifyPage();
		return blogPage;
	}
}