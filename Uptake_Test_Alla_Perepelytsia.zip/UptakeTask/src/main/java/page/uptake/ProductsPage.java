package page.uptake;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import page.AbstractPage;

public class ProductsPage extends AbstractPage {

	By productsPage = new By.ByXPath(".//a[contains(@class, 'menu__item menu__item--active') and text() = 'Products']");
	By industriesPageLocator = new By.ByXPath(".//a[contains(@class, 'menu__item') and text() = 'Industries']");

	public void verifyPage() {

		LOGGER.info("Verifying the Products page loaded");
		try {

			wait.until(ExpectedConditions.visibilityOfElementLocated(productsPage));
		} catch (Exception e) {
			String message = "Failed to load the page";
			LOGGER.error(message, e);
			Assert.fail(message + e.getMessage());
		}
	}

	public IndustriesPage openIndustriesPage() {
		LOGGER.info("Opening Industries Page");
		driver.findElement(industriesPageLocator).click();
		IndustriesPage industriesPage = new IndustriesPage();
		industriesPage.verifyPage();
		return industriesPage;

	}
}
