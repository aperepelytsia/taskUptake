package page;

import java.util.ArrayList;

import org.apache.log4j.Logger;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import framewrok.DriverManager;

public abstract class AbstractPage {
	protected Logger LOGGER;

	protected WebDriver driver;
	protected WebDriverWait wait;
	protected String url;
	protected String searchTerm;
	protected String actualPageTitle;
	String actualPageUrl;

	protected AbstractPage() {
		this.driver = DriverManager.getDriver();
		wait = new WebDriverWait(driver, 30);
		LOGGER = Logger.getLogger(this.getClass());
	}

	public void openPage() {
		if (url != null) {
			LOGGER.info("Opening page " + url);
			driver.get(url);
			verifyPage();

		} else {
			String message = "page URL is null";
			LOGGER.error(message);
			throw new RuntimeException(message);
		}
	}

	public abstract void verifyPage();

	{
	}

	public void assertPageTitle(String expectedPageTitle) {
		actualPageTitle = driver.getTitle();
		LOGGER.info("The current page name is: " + actualPageTitle);
		LOGGER.info("Asserting the current page name matches or contains the expected Name: " + expectedPageTitle);
		Assert.assertTrue("The page name did not match!", actualPageTitle.contains(expectedPageTitle));
	}

	public void assertPageURL(String expectedPageUrl) {
		actualPageUrl = driver.getCurrentUrl();
		LOGGER.info("The current page URL is: " + actualPageUrl);
		LOGGER.info("Asserting the current page URL contains: " + expectedPageUrl);
		Assert.assertTrue("The page URL did not match!", actualPageUrl.contains(expectedPageUrl));

	}
	public void switchTabs (int i) {
		ArrayList<String> windowHandles = new ArrayList<String> (driver.getWindowHandles());
		driver.switchTo().window(windowHandles.get(i));
	}
}
