package util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PropertiesLoader {

	public static Properties loadFile(String fileName) {

		Properties props = new Properties();

		InputStream inputStream = PropertiesLoader.class.getClassLoader().getResourceAsStream(fileName);

		if (inputStream == null) {
			throw new RuntimeException("Could not find file: " + fileName);
		}
		try {
			props.load(inputStream);
		} catch (IOException e) {
			throw new RuntimeException("Error loading file: " + fileName, e);

		}
		return props;
	}
}
