package util;
import java.util.Properties;

public class UrlProvider {
	

		private static final String PROPERTIES_FILE_NAME = "url.properties";
		private static Properties props;

		//public UrlProvider() {
		static {
			props = PropertiesLoader.loadFile(PROPERTIES_FILE_NAME);
		}
		//}

		public static String getUrl(String key) {

			String value = null;
			value = props.getProperty(key);
			return value;
		}

}
