package util;

import java.util.Properties;

public class ConfigurationProvider {

	private static final String PROPERTIES_FILE_NAME = "config.properties";
	private static Properties props;

	static {
		props = PropertiesLoader.loadFile(PROPERTIES_FILE_NAME);

	}

	public static String getValue(String key) {

		String value = null;
		value = props.getProperty(key);
		return value;
	}

	public static int getInt(String key) {
		int result;

		String keyValue = getValue(key);
		result = Integer.valueOf(keyValue);
		return result;

	}

	public static Object getIntegerValue(Object key) {

		Object intValue = null;
		intValue = props.get(key);

		return intValue;

	}

	public static boolean getBoolean(String key) {
		boolean result = false;

		String keyValue = getValue(key);
		// result = Boolean.parseBoolean(keyValue);
		result = Boolean.valueOf(keyValue);

		return result;
	}

}