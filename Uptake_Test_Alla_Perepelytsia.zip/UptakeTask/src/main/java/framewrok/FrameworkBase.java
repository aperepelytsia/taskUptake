package framewrok;


import org.openqa.selenium.WebDriver;
import org.apache.log4j.Logger;
import org.junit.After;
import org.junit.Before;


public class FrameworkBase {
	
	final static Logger LOGGER = Logger.getLogger(FrameworkBase.class);
	private static final String HORIZONTAL_SEPARATOR = "============================================================";
	protected WebDriver driver;

	@Before
	public void setup() {
		LOGGER.info("Test starting");
		DriverManager.getDriver();
		LOGGER.info(HORIZONTAL_SEPARATOR);
	
	}

	@After
	public void teardown() {
			LOGGER.info(HORIZONTAL_SEPARATOR);
			LOGGER.info("Test finished");
			
			DriverManager.quitDriver();
			
		    LOGGER.info(HORIZONTAL_SEPARATOR);
		}
}
