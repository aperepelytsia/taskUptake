package framewrok;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import util.ConfigurationProvider;


public class DriverManager {
	private static final Logger LOGGER = Logger.getLogger(DriverManager.class);

	private static ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<WebDriver>();

	public static WebDriver getDriver() {

		WebDriver driver = driverThreadLocal.get();
		if (driver == null) {
			startDriver();
		}
		driver = driverThreadLocal.get();
		return driver;

	}

	public static void quitDriver() {
		LOGGER.info("Quitting the driver");
		WebDriver driver = driverThreadLocal.get();
		driver.quit();
		
		driverThreadLocal.set(null);
	
	}

	private static void startDriver() {
		WebDriver driver;
		String message;

		String browser = ConfigurationProvider.getValue("browser.name");

		LOGGER.info("Starting driver...");
		LOGGER.trace("browser from properties: " + browser);

		switch (browser) {
		case "firefox":
			driver = new FirefoxDriver();
			break;

		case "chrome":
			driver = new ChromeDriver();
			break;

		default:

			message = "Unknown browser requested: " + browser;
			LOGGER.info(message);
			throw new RuntimeException(message);
		}
		message = "browser from properties: " + browser;
		LOGGER.info(message);
		driverThreadLocal.set(driver);
		driver.manage().window().maximize();

	}

}
