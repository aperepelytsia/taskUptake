package uptakeTest;

import org.junit.Test;

import framewrok.FrameworkBase;
import page.uptake.AboutPage;
import page.uptake.BeyondUptakePage;
import page.uptake.BlogPage;
import page.uptake.IndustriesPage;
import page.uptake.NewsroomPage;
import page.uptake.ProductsPage;
import page.uptake.UptakeFrontPage;


public class UptakeTest extends FrameworkBase {
	
	@Test
	public void verifyFrontPage() {
		String expectedFrontPageTitle = "Analytics for the industrial internet";
		String expectedFrontTitle = "Actionable Insights." + "\n" + "Faster, Better Results.";
		String expectedAboutPageTitle = "About";
		String expectedAboutPageUrl = "/about";
		String expectedProductsPageTitle = "Products";
		String expectedProductsPageUrl = "/products";
		String expectedIndustriesPageTitle = "Industries";
		String expectedIndustriesPageUrl = "/industries";
		String expectedNewsroomPageTitle = "Newsroom";
		String expectedNewsroomsPageUrl = "/newsroom";
		String expectedBeyondUptakePageTitle = "beyond.uptake";
		String expectedBeyondUptakePageUrl = "https://beyond.uptake.com/";
		String expectedBlogPageTitle = "Blog";
		String expectedBlogPageUrl = "https://blog.uptake.com/";
		
		UptakeFrontPage uptakeFrontPage = new UptakeFrontPage();
		uptakeFrontPage.openPage();
		uptakeFrontPage.verifyFrontTitle(expectedFrontTitle);
		uptakeFrontPage.assertPageTitle(expectedFrontPageTitle);
		
		AboutPage aboutPage = uptakeFrontPage.openAboutPage();
		aboutPage.assertPageTitle(expectedAboutPageTitle);
		aboutPage.assertPageURL(expectedAboutPageUrl);
		
		ProductsPage productsPage = aboutPage.openProductsPage();
		productsPage.assertPageTitle(expectedProductsPageTitle);
		productsPage.assertPageURL(expectedProductsPageUrl);
		
		IndustriesPage industriesPage = productsPage.openIndustriesPage();
		industriesPage.assertPageTitle(expectedIndustriesPageTitle);
		industriesPage.assertPageURL(expectedIndustriesPageUrl);
		
		NewsroomPage newsroomPage = industriesPage.openNewsroomPage();
		newsroomPage.assertPageTitle(expectedNewsroomPageTitle);
		newsroomPage.assertPageURL(expectedNewsroomsPageUrl);
		
		BeyondUptakePage beyondUptakePage = newsroomPage.openBeyondUptakePage();
		beyondUptakePage.assertPageTitle(expectedBeyondUptakePageTitle);
		beyondUptakePage.assertPageURL(expectedBeyondUptakePageUrl);
		beyondUptakePage.returnToNewsroomPage();

		BlogPage blogPage = newsroomPage.openBlogPage();
		blogPage.assertPageTitle(expectedBlogPageTitle);
		blogPage.assertPageURL(expectedBlogPageUrl);
		
	
	}
}